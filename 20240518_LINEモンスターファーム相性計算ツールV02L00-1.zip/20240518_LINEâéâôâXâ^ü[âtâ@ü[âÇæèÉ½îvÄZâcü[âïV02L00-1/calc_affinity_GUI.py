"""
   Copyright 2024/5/18 sean of copyright owner

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

	端的に言えば、改変/二次配布は自由ですが、一切責任は負いません！
	配布時は、必ず"sean"の名前と上記文章をコピーして渡すように！って感じです！
	(改変時は面倒ではありますが変更履歴/内容も記載してください。)

"""

import tkinter as tk
import tkinter.font
from tkinter import IntVar
import tkinter.ttk as ttk
from tkinter import messagebox
from tkinter import scrolledtext 
from tkinter import filedialog

import pandas as pd

import datetime
import os
import time



# モンスターの情報を取り扱うクラス。
class Monster():
    
    def __init__(self):
        self.name = ""      #  モンスター名
        self.pedigree1 = "" #  主血統
        self.pedigree2 = "" #  副血統
        self.ped1_num  = 99 #  主血統ID（モンスター名をあいうえお順に並び変えて割り振ったID。レアモンは使わないが0に設定。）
        self.ped2_num  = 99 #  副血統ID（モンスター名をあいうえお順に並び変えて割り振ったID。レアモンは0に設定。）
    
    def __init__(self, name="", pedigree1="", pedigree2="", ped1_num=99, ped2_num=99):
        self.name = name 
        self.pedigree1 = pedigree1
        self.pedigree2 = pedigree2
        self.ped1_num  = ped1_num
        self.ped2_num  = ped2_num
    
    # テーブル情報を使用してモンスター名から主血統/副血統関連の情報をセットするメソッド。
    def set_pedigree(self, df_monsters):

        pedigree_num = df_monsters["主血統ID"].max()  # 主血統の個数（レアモン含まない。）
        df_monster = df_monsters[df_monsters["モンスター名"] == self.name]

        if not df_monster.empty:
            self.pedigree1 = df_monster.iloc[0, 1]
            self.pedigree2 = df_monster.iloc[0, 2]
            self.ped1_num  = [df_monster.iloc[0, 3]]
            self.ped2_num  = [df_monster.iloc[0, 4]]
        else:
            self.ped1_num = [i for i in range(pedigree_num+1)] # レアモン分を忘れずに加算。(0行目に置いている影響で必要。)
            self.ped2_num = [i for i in range(pedigree_num+1)] # レアモン分を忘れずに加算。
    
    def info(self):
        print(f"==================================")
        print(f"         Name: " + self.name)
        print(f"Main Pedegree: {self.ped1_num} {self.pedigree1}")



# 相性値計算時の閾値保管用クラス
class ThreshAff():
    
    def __init__(self):
        # 以下の値未満の相性値の場合、計算をスキップしている。
        self.th_ped1_cpg = 112  #  子-親-祖父-祖母間の主血統相性値閾値
        self.th_ped2_cpg = 96   #  子-親-祖父-祖母間の副血統相性値閾値
        self.th_ped1_pp = 35    #  親①-親②間の主血統相性値閾値
        self.th_ped2_pp = 32    #  親①-親②間の副血統相性値閾値
        self.th_p1 = 75         #  子-親①間の主/副血統相性値合計閾値
        self.th_p2 = 75         #  子-親②間の主/副血統相性値合計閾値
        self.th_cpg1 = 30       #  親①家系の子-祖 or 親-祖間の主/副血統相性値合計閾値
        self.th_cpg2 = 30       #  親②家系の子-祖 or 親-祖間の主/副血統相性値合計閾値

    
    def __init__(self, th_ped1_cpg=112, th_ped2_cpg=96, th_ped1_pp=35, th_ped2_pp=32, th_p1=75, th_p2=75, th_cpg1=70, th_cpg2=70):
        self.th_ped1_cpg = th_ped1_cpg
        self.th_ped2_cpg = th_ped2_cpg
        self.th_ped1_pp = th_ped1_pp
        self.th_ped2_pp = th_ped2_pp
        self.th_p1 = th_p1
        self.th_p2 = th_p2
        self.th_cpg1 = th_cpg1
        self.th_cpg2 = th_cpg2
        
    
    def info(self):
        print(f"子-親-祖父-祖母メイン血統の相性値閾値　　　　　　　　　　：{self.th_ped1_cpg}")
        print(f"子-親-祖父-祖母サブ血統の相性値閾値　　　　　　　　　　　：{self.th_ped2_cpg}")
        print(f"親①-親②メイン血統の相性値閾値　　　　　　　　　　　　　　：{self.th_ped1_pp}")
        print(f"親①-親②サブ血統の相性値閾値　　　　　　　　　　　　　　　：{self.th_ped2_pp}")
        print(f"子-親①間のメイン/サブ血統相性値合計閾値　　　　　　　　　：{self.th_p1}")
        print(f"子-親②間のメイン/サブ血統相性値合計閾値　　　　　　　　　：{self.th_p2}")
        print(f"親①家系の子-祖 or 親-祖間のメイン/サブ血統相性値合計閾値 ：{self.th_cpg1}")
        print(f"親②家系の子-祖 or 親-祖間のメイン/サブ血統相性値合計閾値 ：{self.th_cpg2}")



class Application(tk.Frame):
    def __init__(self, master = None):
        super().__init__(master)

        #### 事前設定
        # 参照ファイル名の設定(配下でインスタンス変数を作成しているため注意。)
        ret = self.set_filename()
        if not ret:
            master.destroy()
            return

        # 付属データの読み込み/リストへの変換(配下でインスタンス変数を作成しているため注意。)
        self.read_all_data()

        # モンスター名リストに主血統ID/副血統IDを相性表を元に追加
        ret = self.add_monster_id()
        if  not ret:
            master.destroy()
            return
        
        # コンボボックス向けレアモンのレコードを追加
        self.add_raremon()

        # 読み込んだデータからリーグ表作成(配下でインスタンス変数を作成しているため注意。)
        self.create_league_table()

        # コンボボックス用の初期リストの作成(配下でインスタンス変数を作成しているため注意。)
        self.create_combo_list()
        
        # フォント指定
        self.font_l = tk.font.Font(master, family="メイリオ", size = 25)
        self.font_m = tk.font.Font(master, family="メイリオ", size = 15)
        self.font_s = tk.font.Font(master, family="メイリオ", size = 11)


        ######## メインウィンドウの作成 ##########

        #### 設定画面の作成
        # 基本設定
        master.title("△〇 LINE:モンスターファーム モンスター相性計算ツール ◎☆")
        master.geometry('1550x800')
        master.resizable(0, 0)

        # frameの作成/配置
        frame0_title     = tk.Frame(master, width=740, height=20)
        frame1_table     = tk.LabelFrame(master, width=740, height=60, text="モンスター参照テーブル設定", font=self.font_m)
        frame2_monster   = tk.LabelFrame(master, width=740, height=100, text="モンスター名設定", font=self.font_m)
        frame3_thresh    = tk.LabelFrame(master, width=740, height=60, text="相性値閾値設定", font=self.font_m)
        frame4_sbutton   = tk.Frame(master, width=740, height=10)
        frame0_title.pack(padx=10, pady=2, fill='both', expand=True)
        frame1_table.pack(padx=30, pady=7, fill='both', expand=True)
        frame2_monster.pack(padx=30, pady=7, fill='both', expand=True)
        frame3_thresh.pack(padx=30, pady=7, fill='both', expand=True)
        frame4_sbutton.pack(padx=200, pady=7, fill='both', expand=True)


        #### 画面上部の設定
        label_f0 = tk.Label(frame0_title, text = "LINE:モンスターファーム モンスター相性計算ツール Ver2.0.1", font=self.font_l) 
        label_f0.pack()

        ### 計算方法の設定★★★
        # 計算手法をmin(m)系、min(m+s)系に変更するなら、最初に設定変更して、そのフラグで、以下のフラグを変更するようにする。
        # 関連個所に次のラベルを付与しておく → ★計算手法変更時確認★

        #### 参照テーブルの設定
        # 整数の保持用にインスタンスを作成
        self.number_f1_c = IntVar(value=1)
        self.number_f1_pg = IntVar(value=1)

        # ラベルの作成
        label_f1_cpg_s1 = tk.Label(frame1_table, text = "　子/親祖父母毎に検索で使用するテーブルを設定します。玄人の方はdataフォルダのcsvをカスタマイズして自分用にすることも可能です。", font=self.font_s) 
        label_f1_c_l1 = tk.Label(frame1_table, text = "子", font=self.font_s) 
        label_f1_pg_l2 = tk.Label(frame1_table, text = "親祖父母", font=self.font_s) 

        # ラジオボタンの作成
        radio_f1_c1 = tk.Radiobutton(frame1_table, text='純血統+レア', variable=self.number_f1_c, value=0, command=self.radio_set_c_cmb_th, font=self.font_s)
        radio_f1_c2 = tk.Radiobutton(frame1_table, text='全モンスター', variable=self.number_f1_c, value=1, command=self.radio_set_c_cmb_th, font=self.font_s)
        radio_f1_c3 = tk.Radiobutton(frame1_table, text='全モンスター(純血統のみ除く)', variable=self.number_f1_c, value=2, command=self.radio_set_c_cmb_th, font=self.font_s)
        radio_f1_pg1 = tk.Radiobutton(frame1_table, text='純血統+レア', variable=self.number_f1_pg, value=0, command=self.radio_set_pg_cmb_th, font=self.font_s)
        radio_f1_pg2 = tk.Radiobutton(frame1_table, text='全モンスター', variable=self.number_f1_pg, value=1, command=self.radio_set_pg_cmb_th, font=self.font_s)
        radio_f1_pg3 = tk.Radiobutton(frame1_table, text='全モンスター(純血統のみ除く)', variable=self.number_f1_pg, value=2, command=self.radio_set_pg_cmb_th, font=self.font_s)

        # 配置
        label_f1_cpg_s1.grid(row=0, column=0, padx=5, pady=2, columnspan=4, sticky=tk.W)
        label_f1_c_l1.grid(row=1, column=0, padx=5, pady=2)
        label_f1_pg_l2.grid(row=2, column=0, padx=5, pady=2)
        radio_f1_c1.grid(row=1, column=1, padx=5, pady=2)
        radio_f1_c2.grid(row=1, column=2, padx=5, pady=2)
        radio_f1_c3.grid(row=1, column=3, padx=5, pady=2)
        radio_f1_pg1.grid(row=2, column=1, padx=5, pady=2)
        radio_f1_pg2.grid(row=2, column=2, padx=5, pady=2)
        radio_f1_pg3.grid(row=2, column=3, padx=5, pady=2)


        #### モンスター設定
        # 整数の保持用にインスタンスを作成
        self.num_mons = 7

        # ラベルの作成
        label_f2_m_s1 = tk.Label(frame2_monster, text = "　ここで検索したいモンスターの設定をします。全て空白でも検索可能ですが、相性値閾値設定次第で候補過多で出力されなくなるため注意。(メイン/サブ血統欄はモンスター名絞込み用の設定です。)", font=self.font_s) 
        label_f2_m_l1 = tk.Label(frame2_monster, text = "モンスター名", font=self.font_s) 
        label_f2_m_l2 = tk.Label(frame2_monster, text = "メイン血統", font=self.font_s) 
        label_f2_m_l3 = tk.Label(frame2_monster, text = "サブ血統", font=self.font_s) 
        label_f2_m1 = tk.Label(frame2_monster, text = "子", font=self.font_s) 
        label_f2_m2 = tk.Label(frame2_monster, text = "親①", font=self.font_s) 
        label_f2_m3 = tk.Label(frame2_monster, text = "祖父①", font=self.font_s) 
        label_f2_m4 = tk.Label(frame2_monster, text = "祖母①", font=self.font_s) 
        label_f2_m5 = tk.Label(frame2_monster, text = "親②", font=self.font_s) 
        label_f2_m6 = tk.Label(frame2_monster, text = "祖父②", font=self.font_s) 
        label_f2_m7 = tk.Label(frame2_monster, text = "祖母②", font=self.font_s) 

        # コンボボックスの作成
        self.combos_f2_m1 = [0] * self.num_mons
        self.combos_f2_m2 = [0] * self.num_mons
        self.combos_f2_m3 = [0] * self.num_mons
        for i in range(self.num_mons):
            self.combos_f2_m1[i] = ttk.Combobox(frame2_monster, state='readonly', values=self.lis_mons_names, width=16, font=self.font_s)
            self.combos_f2_m1[i].bind("<<ComboboxSelected>>", lambda event: self.entry_set_th_from_cmb2(event))
            # debug code start 
            """
            if i == 0:
               self.combos_f2_m1[i].set("ネンドロ")
            else:
                self.combos_f2_m1[i].set("ピクシー")
            """
            # debug code end
        for i in range(self.num_mons):
            self.combos_f2_m2[i] = ttk.Combobox(frame2_monster, state='readonly', values=self.lis_main_ped, width=16, font=self.font_s)
            self.combos_f2_m2[i].bind("<<ComboboxSelected>>", lambda event, num=i: self.combo_set_cmb(event, num))
        for i in range(self.num_mons):
            self.combos_f2_m3[i] = ttk.Combobox(frame2_monster, state='readonly', values=self.lis_sub_ped, width=16, font=self.font_s)
            self.combos_f2_m3[i].bind("<<ComboboxSelected>>", lambda event, num=i: self.combo_set_cmb(event, num))

        # ボタン作成
        self.button_f2_r = tk.Button(frame2_monster, text="リセット", command=self.button_reset_cmb, font=self.font_s)

        # 配置
        label_f2_m_s1.grid(row=0, column=0, padx=5, pady=3, columnspan=8, sticky=tk.W)
        label_f2_m_l1.grid(row=2, column=0, padx=5, pady=3)
        label_f2_m_l2.grid(row=3, column=0, padx=5, pady=3)
        label_f2_m_l3.grid(row=4, column=0, padx=5, pady=3)
        label_f2_m1.grid(row=1, column=1, padx=5, pady=3)
        label_f2_m2.grid(row=1, column=2, padx=5, pady=3)
        label_f2_m3.grid(row=1, column=3, padx=5, pady=3)
        label_f2_m4.grid(row=1, column=4, padx=5, pady=3)
        label_f2_m5.grid(row=1, column=5, padx=5, pady=3)
        label_f2_m6.grid(row=1, column=6, padx=5, pady=3)
        label_f2_m7.grid(row=1, column=7, padx=5, pady=3)
        for i in range(self.num_mons):
            self.combos_f2_m1[i].grid(row=2, column=i+1, padx=5, pady=3)
        for i in range(self.num_mons):
            self.combos_f2_m2[i].grid(row=3, column=i+1, padx=5, pady=3)
        for i in range(self.num_mons):
            self.combos_f2_m3[i].grid(row=4, column=i+1, padx=5, pady=3)
        self.button_f2_r.grid(row=4, column=8, padx=5, pady=3)


        #### 相性閾値設定
        # ラベルの作成
        label_f3_t_s1 = tk.Label(frame3_thresh, text = "　　本項目での設定値未満の相性値の場合、検索候補から除外します。（よくわからない場合はそのままで問題なし。）", font=self.font_s) 
        label_f3_t1 = tk.Label(frame3_thresh, text = " a.子-親-祖父-祖母メイン血統の相性閾値：", font=self.font_s, state=tk.DISABLED) 
        label_f3_t2 = tk.Label(frame3_thresh, text = " b.子-親-祖父-祖母サブ  血統の相性閾値：", font=self.font_s, state=tk.DISABLED)
        label_f3_t3 = tk.Label(frame3_thresh, text = "c.　　親①-親②メイン血統の相性閾値：", font=self.font_s) 
        label_f3_t4 = tk.Label(frame3_thresh, text = "d.　　親①-親②サブ  血統の相性閾値：", font=self.font_s) 
        label_f3_t5 = tk.Label(frame3_thresh, text = "　　e. 　　　　　　　　　子-親①間のメイン/サブ血統相性値合計閾値：", font=self.font_s) 
        label_f3_t6 = tk.Label(frame3_thresh, text = "　　f. 　　　　　　　　　子-親②間のメイン/サブ血統相性値合計閾値：", font=self.font_s) 
        label_f3_t7 = tk.Label(frame3_thresh, text = "　　g. 親①家系の子-祖 or 親-祖間のメイン/サブ血統相性値合計閾値 ：", font=self.font_s) 
        label_f3_t8 = tk.Label(frame3_thresh, text = "　　h. 親②家系の子-祖 or 親-祖間のメイン/サブ血統相性値合計閾値 ：", font=self.font_s) 
        
        # エントリーの作成
        self.entry_f3_t1 = tk.Entry(frame3_thresh, width=10, font=self.font_s, state=tk.DISABLED)
        self.entry_f3_t2 = tk.Entry(frame3_thresh, width=10, font=self.font_s, state=tk.DISABLED)
        self.entry_f3_t3 = tk.Entry(frame3_thresh, width=10, font=self.font_s)
        self.entry_f3_t4 = tk.Entry(frame3_thresh, width=10, font=self.font_s)
        self.entry_f3_t5 = tk.Entry(frame3_thresh, width=10, font=self.font_s)
        self.entry_f3_t6 = tk.Entry(frame3_thresh, width=10, font=self.font_s)
        self.entry_f3_t7 = tk.Entry(frame3_thresh, width=10, font=self.font_s)
        self.entry_f3_t8 = tk.Entry(frame3_thresh, width=10, font=self.font_s)
        # ★計算手法変更時確認★
        self.entry_set_th2()

        # 配置
        label_f3_t_s1.grid(row=0, column=0, padx=5, pady=3, columnspan=8, sticky=tk.W)
        label_f3_t1.grid(row=1, column=0, padx=5, pady=2)
        label_f3_t2.grid(row=2, column=0, padx=5, pady=2)
        label_f3_t3.grid(row=3, column=0, padx=20, pady=2)
        label_f3_t4.grid(row=4, column=0, padx=20, pady=2)
        label_f3_t5.grid(row=1, column=2, padx=5, pady=2)
        label_f3_t6.grid(row=2, column=2, padx=5, pady=2)
        label_f3_t7.grid(row=3, column=2, padx=5, pady=2)
        label_f3_t8.grid(row=4, column=2, padx=5, pady=2)
        self.entry_f3_t1.grid(row=1, column=1, padx=1, pady=2)
        self.entry_f3_t2.grid(row=2, column=1, padx=1, pady=2)
        self.entry_f3_t3.grid(row=3, column=1, padx=1, pady=2)
        self.entry_f3_t4.grid(row=4, column=1, padx=1, pady=2)
        self.entry_f3_t5.grid(row=1, column=3, padx=1, pady=2)
        self.entry_f3_t6.grid(row=2, column=3, padx=1, pady=2)
        self.entry_f3_t7.grid(row=3, column=3, padx=1, pady=2)
        self.entry_f3_t8.grid(row=4, column=3, padx=1, pady=2)


        #### 検索ボタン設定
        # ボタン作成
        button_f4_s = tk.Button(frame4_sbutton, text="検索開始！", command=self.button_calc_affinity, font=self.font_s)
        button_f4_s.pack(fill=tk.BOTH)
        frame4_sbutton.grid_propagate(1)


        ######## サブウィンドウの作成 ##########

        #### 検索結果表示Windowの作成
        # 基本設定
        sub_window = tk.Toplevel()
        sub_window.title("モンスター相性計算ツール ～計算結果～")
        sub_window.geometry('1000x800+1000+50')
        sub_window.resizable(0, 0)

        # frameの作成/配置(, bg="blue")
        s_frame1_Log  = tk.LabelFrame(sub_window, width=740, height=100, text="ログ(設定値や処理時間を記載。)", font=self.font_m)
        s_frame2_result = tk.LabelFrame(sub_window, width=740, height=700, text="相性値計算結果", font=self.font_m)
        s_frame3_btns   = tk.Frame(sub_window, width=740, height=100)
        s_frame1_Log.pack(side=tk.TOP, padx=5, pady=1, fill=tk.X)
        s_frame2_result.pack(side=tk.TOP, padx=5, pady=1, fill=tk.BOTH, expand=True)
        s_frame3_btns.pack(side=tk.BOTTOM, padx=5, pady=1, fill=tk.X)


        #### ログ出力エリア（設定値、エラー内容確認用）の作成
        # スクロールエリアの作成/配置
        self.text_area_s_f1 = scrolledtext.ScrolledText(s_frame1_Log, wrap=tk.CHAR, width=135, height=10 )
        self.text_area_s_f1.grid(column = 0, pady = 5, padx = 5) 
        self.text_area_s_f1.config(state=tk.DISABLED)


        #### 検索結果内などのための表示領域設定
        # Treeviewオブジェクトの作成
        self.tree_view_s_f2 = ttk.Treeview(s_frame2_result, height=26)
        
        # スクロールバーの設定
        scrollbar_s_f2 = ttk.Scrollbar(s_frame2_result, orient="vertical", command=self.tree_view_s_f2.yview)
        self.tree_view_s_f2.configure(yscrollcommand=scrollbar_s_f2.set)

        # 配置
        scrollbar_s_f2.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_view_s_f2.pack(side=tk.LEFT, fill=tk.X, expand=True) 


        #### 前/次/ログ保存ボタンの作成
        # ボタン作成/配置
        self.offset = 49        # 前/次ボタン用のオフセット。
        self.start_index = 0    # データ表示の開始位置
        self.button_s_f3_back = tk.Button(s_frame3_btns, text="前の50件", command=self.button_back, font=self.font_s, state=tk.DISABLED)
        self.button_s_f3_save = tk.Button(s_frame3_btns, text="結果保存", command=self.button_save, font=self.font_s, state=tk.DISABLED)
        self.button_s_f3_next = tk.Button(s_frame3_btns, text="次の50件", command=self.button_next, font=self.font_s, state=tk.DISABLED)
        self.button_s_f3_back.pack(side=tk.LEFT, expand=True)
        self.button_s_f3_save.pack(side=tk.LEFT, expand=True)
        self.button_s_f3_next.pack(side=tk.LEFT, expand=True)



    #### 各関数
    ## 変数へのファイル名の設定
    def set_filename(self):
        
        ret = False

        # ファイル名の変数格納
        self.fname_monsters   = r"data/monsters.csv"
        self.fname_affinities_main = r"data/affinities_main.csv"
        self.fname_affinities_sub = r"data/affinities_sub.csv"

        # 存在チェック
        if not os.path.isfile(os.getcwd() + "\\" + self.fname_monsters):
            self.show_error(os.getcwd() + "\\" + self.fname_monsters + "が存在しません。適切な場所にファイルを格納して再起動してください。")
            return ret
        if not os.path.isfile(os.getcwd() + "\\" + self.fname_affinities_main):
            self.show_error(os.getcwd() + "\\" + self.fname_affinities_main + "が存在しません。適切な場所にファイルを格納して再起動してください")
            return ret
        if not os.path.isfile(os.getcwd() + "\\" + self.fname_affinities_sub):
            self.show_error(os.getcwd() + "\\" + self.fname_affinities_sub + "が存在しません。適切な場所にファイルを格納して再起動してください")
            return ret
        
        ret = True
        
        return ret
    

    ## エラーメッセージをポップアップで表示。
    def show_error(self, message):

        messagebox.showerror('エラー', message)
        
        return
    

    ## 警告文をポップアップで表示
    def show_warning(self, message):

        messagebox.showwarning('警告', message)

        return


    ## 各種データの読み込み+listへの変換
    def read_all_data(self):
        
        # csvの読み込み + list変換
        self.df_monsters = pd.read_csv(self.fname_monsters)
        self.df_affinities_m_cp = pd.read_csv(self.fname_affinities_main, index_col=0)
        self.lis_affinities_m_cp = self.df_affinities_m_cp.values.tolist()
        self.df_affinities_s_cp = pd.read_csv(self.fname_affinities_sub, index_col=0)
        self.lis_affinities_s_cp = self.df_affinities_s_cp.values.tolist()

        # ★計算手法変更時確認★ 両方使用する予定あるから、事前計算はどちらのテーブルも実施しておく。

        # 事前計算①(min(m)用。)
        self.lis_affinities_m_cpg = self.precalc_affinity_cpg(self.lis_affinities_m_cp)
        self.lis_affinities_s_cpg = self.precalc_affinity_cpg(self.lis_affinities_s_cp)

        # 事前計算②(min(m+s)用。)
        self.lis_affinities_m_s_cp = self.precalc_affinity_m_s_cp(self.lis_affinities_m_cp, self.lis_affinities_s_cp)

        # 結果格納用
        self.df_affinities = pd.DataFrame()

        return
    

    ## モンスター名リストに対して、相性表を参照して主血統ID/副血統IDの列を追加する。
    ## 返り値注意。(追加出来たらTrue,追加できなかったらFalse)
    ## また、モンスター名リストで不具合があればサイレントで削除する。
    def add_monster_id(self):

        # 変数初期化
        ret = False

        # 主血統ID/副血統ID列を初期化
        self.df_monsters["主血統ID"] = -1
        self.df_monsters["副血統ID"] = -1
        
        # メイン血統相性表、サブ血統相性表の各インデックス名/列名を取得
        name_list_m_row = self.df_affinities_m_cp.index.to_list()
        name_list_m_col = self.df_affinities_m_cp.columns.to_list()
        name_list_s_row = self.df_affinities_s_cp.index.to_list()
        name_list_s_col = self.df_affinities_s_cp.columns.to_list()

        ## 相性表の対応関係に問題ないかをチェック
        # チェック用のローカル関数を作成
        def is_same_list(list1, list2):
            # 長さチェック
            if len(list1) != len(list2):
                return False
            # モンスター名チェック
            for i in range(len(list1)):
                if list1[i] != list2[i]:
                    return False
            return True
        
        # メイン血統のインデックス名/列名で順番が同じになっているかチェック
        if not is_same_list(name_list_m_row, name_list_m_col):
            self.show_error("affinities_main.csvのインデックス名/列名の対応関係がとれていません。\n同じ順番にしてください。")
            return ret

        # サブ血統のインデックス名/列名で順番が同じになっているかチェック
        if not is_same_list(name_list_s_row, name_list_s_col):
            self.show_error("affinities_sub.csvのインデックス名/列名の対応関係がとれていません。\n同じ順番にしてください。")
            return ret

        # メイン血統のインデックス名/サブ血統のインデックス名で順番が同じになっているかチェック
        if not is_same_list(name_list_m_row, name_list_s_row):
            self.show_error("affinities_main.csvとaffinities_main.csvで対応関係がとれていません。\n同じ形式の表にしてください。")
            return ret

        # 0番目の行/列がレアになっているかチェック（以降、0番目をレアモンとして処理しているため、事前にチェック）
        if name_list_m_row[0] != "レア":
            self.show_error("affinities_main.csv, affinities_main.csvともに1行目/1列目が\nレアモンの情報ではありません。\n必ず1行目/1列目はレアモンの情報を設定してください。")
            return ret

        # 代表してメイン血統のインデックス名を使用して、df_monstersにIDを追加する
        for i, name in enumerate(name_list_m_row):
            self.df_monsters.loc[self.df_monsters["主血統"] == name, "主血統ID" ] = i
            self.df_monsters.loc[self.df_monsters["副血統"] == name, "副血統ID" ] = i

        # df_monsters中の"主血統ID"または"副血統ID"が-1のレコードは問答無用で削除する。(バグの元となるため。）
        len_before = len(self.df_monsters)
        self.df_monsters = self.df_monsters.drop(self.df_monsters[self.df_monsters['主血統ID'] == -1].index)
        self.df_monsters = self.df_monsters.drop(self.df_monsters[self.df_monsters['副血統ID'] == -1].index)
        len_after = len(self.df_monsters)

        # チェックで削除があった場合は念のため通知しておく。
        if len_before != len_after:
            self.show_warning(f"主血統名/副血統名に問題があったため、全{len_before}件から{len_before - len_after}件削除しました。必要に応じてmonsters.csvを見直してください。")

        # 正常動作
        ret = True

        return ret


    ## モンスター名リストに対して、検索タグ用のレアモンを追加し、ソートする。
    def add_raremon(self):
        
        # 名前比較用のリストを準備
        name_list_m_row = self.df_affinities_m_cp.index.to_list()
        name_list_m_row.remove("レア")

        # レアモンタグのついたレコードの主血統名を抽出
        df_temp = self.df_monsters[self.df_monsters["モンスター名"].str.startswith('(●レア)')]
        name_list_raremon_m = df_temp.iloc[:, 1].to_list()

        # レアモンタグのついたレコードの主血統名のリスト内に、比較用リストの名前がない場合にレコードを追加
        for i, name in enumerate(name_list_m_row):
            if name not in name_list_raremon_m:
                self.df_monsters.loc[f'temp{i}'] = [f'(●レア){name}', name, 'レア', i+1, 0]
        
        # モンスター名のファイルのみソート
        self.df_monsters = self.df_monsters.sort_values(['主血統ID', 'モンスター名'], ascending=[True, True])

        # インデックスをリセットして、新たに発生するindex列を削除
        self.df_monsters = self.df_monsters.reset_index()
        del self.df_monsters['index']

        # debug
        # df_temp = self.df_monsters[["モンスター名", "主血統", "副血統"]]
        # df_temp.to_csv("temp_mons.csv", index=False)
        # debug

        return
    

    # モンスター名リストからリーグ表を3種作成
    # ★所持モンスターチェックをつける場合について
    # 　　原本はそのままにしておいて、どこかで最初に変更して、その変更後のDFを以降の処理参照するようにする。
    def create_league_table(self):
        
        # モンスター名リストをlistに変換
        lis_monsters = self.df_monsters.values.tolist()

        # リーグ表用のリストの初期化
        self.lis_mons_league_tb_all     = [[ "-" for i in range(len(self.lis_affinities_m_cp))] for i in range(len(self.lis_affinities_m_cp))]
        self.lis_mons_league_tb_all_org = [[ "-" for i in range(len(self.lis_affinities_m_cp))] for i in range(len(self.lis_affinities_m_cp))]
        self.lis_mons_league_tb_org     = [[ "-" for i in range(len(self.lis_affinities_m_cp))] for i in range(len(self.lis_affinities_m_cp))]
        
        # レアモンスター用の変数（血統ID、名前保存場所）
        num_rare = 0
        name_rare = "(●レア)"  # "(●レア)"とついたモンスター名を保存する場所。

        # 血統名のリスト
        self.lis_indexes = [ "-" for i in range(len(self.lis_affinities_m_cp))]

        # モンスター名リスト → リーグ表に変換
        for row in lis_monsters:
            if self.lis_mons_league_tb_all[row[3]][row[4]] == "-":
                if row[0].startswith(name_rare):
                    # タグ用のレアモンスター名があってもリーグ表には追加しない。
                    continue
                if row[4] == num_rare:
                    self.lis_mons_league_tb_all[row[3]][row[4]]     = name_rare + row[1]
                    self.lis_mons_league_tb_all_org[row[3]][row[4]] = name_rare + row[1]
                    self.lis_mons_league_tb_org[row[3]][row[4]]     = name_rare + row[1]
                else:
                    self.lis_mons_league_tb_all[row[3]][row[4]]     = row[0]
                    self.lis_mons_league_tb_all_org[row[3]][row[4]] = row[0]
                    
            if row[3] == row[4]:
                self.lis_mons_league_tb_all_org[row[3]][row[4]]     = "-"
                self.lis_mons_league_tb_org[row[3]][row[4]]         = row[0]
        
        # debug start
        # temp1 = pd.DataFrame(self.lis_mons_league_tb_all_org)
        # temp2 = pd.DataFrame(self.lis_mons_league_tb_org)
        # temp3 = pd.DataFrame(self.lis_mons_league_tb_all)
        # temp1.to_csv("temp1.csv")
        # temp2.to_csv("temp2.csv")
        # temp3.to_csv("temp3.csv")
        # debug end

        return


    ## コンボボックスの初期リスト作成
    def create_combo_list(self):

        # メイン血統の絞込み用リスト
        self.lis_main_ped = self.df_affinities_m_cp.index.to_list()
        self.lis_main_ped[0] = ""  # レアモン削除処理 兼 リセット用空白セット処理
        
        # サブ血統の絞込み用リスト
        self.lis_sub_ped = self.df_affinities_s_cp.index.to_list()
        self.lis_sub_ped.insert(0, "")

        # 全モンスター名のリスト
        self.lis_mons_names = self.df_monsters.iloc[:, 0].to_list()
        self.lis_mons_names.insert(0, "")

        # 主血統+レアの名前リスト
        self.df_monsters_org = self.df_monsters[(self.df_monsters["主血統"] == self.df_monsters["副血統"]) | (self.df_monsters["モンスター名"].str.startswith('(●レア)'))].copy()
        self.lis_mons_names_org = self.df_monsters_org.iloc[:, 0].to_list()
        self.lis_mons_names_org.insert(0, "")

        # 主血統のみ除く全モンスター名リスト
        self.df_monsters_ex_org = self.df_monsters[self.df_monsters["主血統"] != self.df_monsters["副血統"]].copy()
        self.lis_mons_names_ex_org = self.df_monsters_ex_org.iloc[:, 0].to_list()
        self.lis_mons_names_ex_org.insert(0, "")

        # コンボボックスの絞込み用のDataFrame型を用意。
        self.df_monsters_c = self.df_monsters
        self.df_monsters_pg = self.df_monsters

        return


    ## ラジオボタン変更後の処理（子のコンボリスト関連の設定）
    def radio_set_c_cmb_th(self):

        if self.number_f1_c.get() == 0:
            self.combos_f2_m1[0].configure(values=self.lis_mons_names_org)
            self.df_monsters_c = self.df_monsters_org
        elif self.number_f1_c.get() == 1:
            self.combos_f2_m1[0].configure(values=self.lis_mons_names)
            self.df_monsters_c = self.df_monsters
        else:
            self.combos_f2_m1[0].configure(values=self.lis_mons_names_ex_org)
            self.df_monsters_c = self.df_monsters_ex_org

        return
    

    ## ラジオボタン変更後の処理（親祖父母のコンボリスト関連の設定）
    def radio_set_pg_cmb_th(self):

        if self.number_f1_pg.get() == 0:
            for i in range(self.num_mons-1):
                self.combos_f2_m1[i+1].configure(values=self.lis_mons_names_org)
            self.df_monsters_pg = self.df_monsters_org
        elif self.number_f1_pg.get() == 1:
            for i in range(self.num_mons-1):
                self.combos_f2_m1[i+1].configure(values=self.lis_mons_names)
            self.df_monsters_pg = self.df_monsters
        else:
            for i in range(self.num_mons-1):
                self.combos_f2_m1[i+1].configure(values=self.lis_mons_names_ex_org)
            self.df_monsters_pg = self.df_monsters_ex_org

        return


    # テキストボックスの内容更新
    # ★計算手法変更時確認★ → min(m+s)の時これ。
    def entry_set_th2(self):
        
        # テキストボックス初期化
        self.entry_f3_t1.delete(0, 100)
        self.entry_f3_t2.delete(0, 100)
        self.entry_f3_t3.delete(0, 100)
        self.entry_f3_t4.delete(0, 100)
        self.entry_f3_t5.delete(0, 100)
        self.entry_f3_t6.delete(0, 100)
        self.entry_f3_t7.delete(0, 100)
        self.entry_f3_t8.delete(0, 100)

        # テキストボックス設定
        self.entry_f3_t1.insert(0, 0)
        self.entry_f3_t2.insert(0, 0)
        self.entry_f3_t3.insert(0, 34)
        self.entry_f3_t4.insert(0, 32)
        self.entry_f3_t5.insert(0, 75)
        self.entry_f3_t6.insert(0, 75)
        self.entry_f3_t7.insert(0, 75)
        self.entry_f3_t8.insert(0, 75)

        return


    # モンスター名のコンボボックス設定後、設定値に応じて相性閾値を変更する。
    # ★計算手法変更時確認★ → min(m+s)の時これ。
    def entry_set_th_from_cmb2(self, event):
        
        # 初期値設定
        total = 0
        is_raremon_c = False
        is_raremon_pg1 = False
        is_raremon_pg2 = False
        num_rare = 0  # レアモンスター用の変数（血統ID）

        # 設定値のカウント
        for i, name in enumerate(self.combos_f2_m1):
            if name.get() != "":
                total += 1
                df_monster = self.df_monsters[self.df_monsters["モンスター名"] == name.get()]
                if not df_monster.empty and df_monster.iloc[0, 4] == num_rare:
                    if i == 0:
                        is_raremon_c = True
                    elif i <= 3:
                        is_raremon_pg1 = True
                    else:
                        is_raremon_pg2 = True

        # 設定値に応じて、相性閾値を算出
        if total != 0:
            
            self.entry_f3_t5.delete(0, 100)
            self.entry_f3_t5.insert(0, 70) 
            self.entry_f3_t6.delete(0, 100)
            self.entry_f3_t6.insert(0, 70)
            self.entry_f3_t7.delete(0, 100)
            self.entry_f3_t7.insert(0, 70)  
            self.entry_f3_t8.delete(0, 100)
            self.entry_f3_t8.insert(0, 70)

            if is_raremon_c:
                self.entry_f3_t5.delete(0, 100)
                self.entry_f3_t5.insert(0, 64)
                self.entry_f3_t6.delete(0, 100)
                self.entry_f3_t6.insert(0, 64)
                self.entry_f3_t7.delete(0, 100)
                self.entry_f3_t7.insert(0, 64)
                self.entry_f3_t8.delete(0, 100)
                self.entry_f3_t8.insert(0, 64)
            
            if is_raremon_pg1:
                self.entry_f3_t5.delete(0, 100)
                self.entry_f3_t5.insert(0, 64)
                self.entry_f3_t7.delete(0, 100)
                self.entry_f3_t7.insert(0, 64)                
            
            if is_raremon_pg2:
                self.entry_f3_t6.delete(0, 100)
                self.entry_f3_t6.insert(0, 64)
                self.entry_f3_t8.delete(0, 100)
                self.entry_f3_t8.insert(0, 64)

        else:
            self.entry_set_th2()
    

        return


    # コンボボックスで値設定後のモンスター名リストの整形
    def combo_set_cmb(self, event, num):
        
        # 設定変更されたコンボボックスを判定して、参照元DataFrameを設定
        if num == 0:
            df = self.df_monsters_c
        else:
            df = self.df_monsters_pg

        # メイン血統を考慮して、モンスター名から不要レコードを削除
        if self.combos_f2_m2[num].get() != "":
            df = df[df["主血統"] == self.combos_f2_m2[num].get()]

        # サブ血統を考慮して、モンスター名から不要レコードを削除
        if self.combos_f2_m3[num].get() != "":
            df = df[df["副血統"] == self.combos_f2_m3[num].get()]

        # それぞれリストに変換して、必要に応じて重複を削除し、先頭に空白を設定。
        # モンスター名
        df = df.sort_values(['主血統ID', 'モンスター名'], ascending=[True, True])
        lis1 = df.iloc[:, 0].to_list()
        lis1.insert(0, "")

        # メイン血統
        df_temp = df.drop_duplicates(subset="主血統")
        lis2 = df_temp.iloc[:, 1].to_list()
        lis2.insert(0, "")
        
        # サブ血統
        df = df.sort_values(['副血統ID', 'モンスター名'], ascending=[True, True])
        df_temp = df.drop_duplicates(subset="副血統")
        lis3 = df_temp.iloc[:, 2].to_list()
        lis3.insert(0, "")
        
        # 設定
        self.combos_f2_m1[num].configure(values=lis1)
        self.combos_f2_m2[num].configure(values=lis2)
        self.combos_f2_m3[num].configure(values=lis3)

        return


    # コンボボックスに設定された値をリセット
    def button_reset_cmb(self):
        
        # モンスター名のコンボボックス参照リストの初期化
        self.radio_set_c_cmb_th()
        self.radio_set_pg_cmb_th()
        
        # コンボボックスの記載内容の初期化
        for i in range(self.num_mons):
            # 絞込み用リストのクリア
            self.combos_f2_m2[i].configure(values=self.lis_main_ped)
            self.combos_f2_m3[i].configure(values=self.lis_sub_ped)
            # テキストクリア
            self.combos_f2_m1[i].set("")
            self.combos_f2_m2[i].set("")
            self.combos_f2_m3[i].set("")
        
        # 合わせて閾値もリセット。
        self.entry_set_th2()

        return


    # 検索開始ボタン押下後の動作
    def button_calc_affinity(self):
        
        ### 事前設定

        # 書き込み有効化
        self.text_area_s_f1.config(state=tk.NORMAL)

        # 実行時刻を出力
        self.print_Log("==================================" + datetime.datetime.now().strftime('%Y年%m月%d日 %H:%M:%S') + "==================================")


        ### 設定画面で設定した内容を各変数に再格納。

        # モンスター名の設定
        child   = Monster(self.combos_f2_m1[0].get())
        parent1 = Monster(self.combos_f2_m1[1].get())
        granpa1 = Monster(self.combos_f2_m1[2].get())
        granma1 = Monster(self.combos_f2_m1[3].get())
        parent2 = Monster(self.combos_f2_m1[4].get())
        granpa2 = Monster(self.combos_f2_m1[5].get())
        granma2 = Monster(self.combos_f2_m1[6].get())
        Monster_info = [child, parent1, granpa1, granma1, parent2, granpa2, granma2]

        # 主血統/副血統の設定
        for i in range(len(Monster_info)):
            Monster_info[i].set_pedigree(self.df_monsters)

        # 相性値閾値設定
        # ★計算手法変更時確認★
        ret, thresh_aff = self.check_aff_thresh()
        if not ret:
            self.show_error("相性値閾値設定欄にて、不正な文字列が入力されています。\n数値を入れてください。")
            return

        # テーブル取得
        lis_mons_league_tb_c, lis_mons_league_tb_pg = self.get_using_table()

        # ログの設定
        self.set_log(Monster_info, thresh_aff)
        

        ### 相性値計算実行/表示処理

        # 前回表示結果を削除
        self.delete_tree()

        # 各ボタンの無効化
        self.button_s_f3_back['state'] = tk.DISABLED
        self.button_s_f3_save['state'] = tk.DISABLED
        self.button_s_f3_next['state'] = tk.DISABLED
        
        # 相性計算
        start_time = time.perf_counter()
        ret, self.df_affinities = self.calc_affinity_m_s(Monster_info, thresh_aff, lis_mons_league_tb_c, lis_mons_league_tb_pg)
        end_time = time.perf_counter()
        elapsed_time = end_time - start_time
        self.print_Log(f"◎処理時間： {elapsed_time:.1f}秒")

        # エラー処理(処理して条件が合えば、以下の処理、合わなければ、書き込み無効化までジャンプ)
        if ret :
            
            # テーブルの整形
            del self.df_affinities["index"]

            # 各ボタンの有効化等
            self.button_s_f3_save['state'] = tk.NORMAL
            self.button_s_f3_next['state'] = tk.NORMAL
            self.start_index = 0

            # 画面上のヘッダ部分の処理（実際はwiget作成時に実行した方が効率が良い。）
            templist = list(self.df_affinities.columns)
            templist.insert(0, "連番")
            self.tree_view_s_f2["columns"] = templist
            self.tree_view_s_f2["show"] = "headings"
            for col in self.df_affinities.columns:
                self.tree_view_s_f2.heading(col, text=col)
                self.tree_view_s_f2.column(col, width=100)
            
            # 画面上へのデータの挿入
            self.insert_tree()
        else:
            # 何もしないで次へ
            pass


        ### 後処理

        # 書き込み無効化
        self.text_area_s_f1.config(state=tk.DISABLED)

        return


    # 前ボタンの定義
    def button_back(self):
        
        # 次50件ボタンの有効化(前の50件ボタンが押せる状態なので、問答無用で有効化)
        self.button_s_f3_next['state'] = tk.NORMAL

        # 現在表示内容の削除
        self.delete_tree()

        # 前回の開始インデックスを算出
        pre_start_index = self.start_index - (self.offset + 1)

        # 開始インデックスの変更
        if pre_start_index > self.offset + 1:
            self.start_index = self.start_index - (self.offset + 1) * 2
        else:
            self.start_index = 0
            self.button_s_f3_back['state'] = tk.DISABLED

        # 画面内容の更新
        self.insert_tree()

        return


    # 次ボタンの定義
    def button_next(self):
        
        # 前50件ボタンの有効化(次の50件ボタンが押せる状態なので、問答無用で有効化)
        self.button_s_f3_back['state'] = tk.NORMAL

        # 現在表示内容の削除
        self.delete_tree()

        # 画面内容の更新
        self.insert_tree()

        return
    

    # 結果表示画面に新しいデータを追加
    def insert_tree(self):
        
        # 初期値設定
        start_index = self.start_index
        end_index   = self.start_index + self.offset

        # 最終値判定処理
        if len(self.df_affinities.index) <= end_index:
            end_index = len(self.df_affinities.index) - 1
            self.start_index = end_index
            self.button_s_f3_next['state'] = tk.DISABLED
        else:
            self.start_index += (self.offset + 1)

        # データ表示
        for index, row in self.df_affinities.loc[start_index:end_index, :].iterrows():
            templist = list(row)
            templist.insert(0, index)
            self.tree_view_s_f2.insert("", "end", values=templist)
        
        return


    # 結果表示画面のデータを削除
    def delete_tree(self):

        # 既存の内容を削除
        for item in self.tree_view_s_f2.get_children():
            self.tree_view_s_f2.delete(item)

        return


    # 画面へのメッセージ出力
    def print_Log(self, message, color="black"):
        
        # タグの設定
        self.text_area_s_f1.tag_config('colored', foreground=color)

        # 出力
        self.text_area_s_f1.insert(tk.END, message+"\n", 'colored')
        self.text_area_s_f1.see('end')

        return


    # 保存ボタンの定義
    def button_save(self):
        
        # 相性値csvの長さを確認して調整
        length = len(self.df_affinities.index)
        if 10000 < length:
            length = 10000

        # タイムスタンプを作成
        tag = datetime.datetime.now().strftime('%Y%m%d%H%M%S')

        # 保存
        file_name = filedialog.asksaveasfilename(title='名前をつけて保存', filetypes=[('CSV', '.csv')], initialdir='./', defaultextension='.csv', initialfile=f"モンスター相性値_{tag}.csv")
        self.df_affinities.loc[0:length-1, :].to_csv(file_name)

        # Webアプリ化の際は注意。別ボタンで用意するか、2回ポップアップ出すかする。
        # 現在のログ内容も保存しておく。
        file_name_log = "log_" + tag + ".txt"

        # テキストエリアの内容を取得
        text_to_save = self.text_area_s_f1.get("1.0", tk.END)

        # ファイルに書き込み
        with open(file_name_log, "w") as file:
            file.write(text_to_save)

        return


    # 検索時に使用した各種値をログに出力する。
    def set_log(self, Monster_info, thresh_aff):

        message_list1 = ['純血統+レア','全モンスター', '全モンスター(純血統のみ除く)']
        message_list2 = ["子", "親①", "祖父①", "祖母①", "親②", "祖父②", "祖母②"]

        # 参照テーブル
        self.print_Log(f"◎モンスター参照テーブル：")
        self.print_Log(f"　　　　　子：{message_list1[self.number_f1_c.get()]}")
        self.print_Log(f"　　親祖父母：{message_list1[self.number_f1_pg.get()]}")

        # 指定モンスター
        self.print_Log(f"◎モンスター名：")
        for i, monster in enumerate(Monster_info):
            size1 = 10 - len(message_list2[i])
            if monster.name.startswith("("):
                size2 = 24 - len(monster.name)
            else:
                size2 = 22 - len(monster.name)
            size3 = 12 - len(monster.pedigree1)
            size4 = 12 - len(monster.pedigree2)
            self.print_Log(f"{message_list2[i]:>{size1}}:{monster.name:>{size2}}, メイン：{monster.pedigree1:>{size3}}, サブ：{monster.pedigree2:>{size4}}")

        # 閾値
        self.print_Log(f"◎相性値閾値：")
        self.print_Log(f"　　a.子-親-祖父-祖母メイン血統の相性値閾値　　　　　　　　　　 ：{thresh_aff.th_ped1_cpg}")
        self.print_Log(f"　　b.子-親-祖父-祖母サブ血統の相性値閾値　　　　　　　　　　　 ：{thresh_aff.th_ped2_cpg}")
        self.print_Log(f"　　c.親①-親②メイン血統の相性値閾値　　　　　　　　　　　　　 ：{thresh_aff.th_ped1_pp}")
        self.print_Log(f"　　d.親①-親②サブ血統の相性値閾値　　　　　　　　　　　　　　 ：{thresh_aff.th_ped2_pp}")
        self.print_Log(f"　　e.子-親①間のメイン/サブ血統相性値合計閾値　　　　　　　　　：{thresh_aff.th_p1}")
        self.print_Log(f"　　f.子-親②間のメイン/サブ血統相性値合計閾値　　　　　　　　　：{thresh_aff.th_p2}")
        self.print_Log(f"　　g.親①家系の子-祖 or 親-祖間のメイン/サブ血統相性値合計閾値 ：{thresh_aff.th_cpg1}")
        self.print_Log(f"　　h.親②家系の子-祖 or 親-祖間のメイン/サブ血統相性値合計閾値 ：{thresh_aff.th_cpg2}")

        return


    # 数値チェック関数
    def is_num(self, s):
        try:
            float(s)
        except ValueError:
            return False
        else:
            return True


    # 相性閾値の設定値確認/値設定
    # ★計算手法変更時確認★ → むやみにテキストボックス無効化すると、ここでエラーになる。
    def check_aff_thresh(self):

        ret = True
        thresh_aff = ThreshAff()
        
        # 設定値の数値チェック/設定
        """
        if not self.is_num(self.entry_f3_t1.get()):
            ret = False
        elif not self.is_num(self.entry_f3_t2.get()):
            ret = False
        elif not self.is_num(self.entry_f3_t3.get()):
        """
        if not self.is_num(self.entry_f3_t3.get()):
            ret = False
        elif not self.is_num(self.entry_f3_t4.get()):
            ret = False
        elif not self.is_num(self.entry_f3_t5.get()):
            ret = False
        elif not self.is_num(self.entry_f3_t6.get()):
            ret = False
        elif not self.is_num(self.entry_f3_t7.get()):
            ret = False
        elif not self.is_num(self.entry_f3_t8.get()):
            ret = False
        else:
            # 設定
            thresh_aff = ThreshAff(0.0, 0.0, float(self.entry_f3_t3.get()), float(self.entry_f3_t4.get())
                                   , float(self.entry_f3_t5.get()), float(self.entry_f3_t6.get()), float(self.entry_f3_t7.get()), float(self.entry_f3_t8.get()))

        return ret, thresh_aff


    # 相性値計算時に使用するテーブルを取得
    def get_using_table(self):

        if self.number_f1_c.get() == 0:
            lis_mons_league_tb_c = self.lis_mons_league_tb_org
        elif self.number_f1_c.get() == 1:
            lis_mons_league_tb_c = self.lis_mons_league_tb_all
        else:
            lis_mons_league_tb_c = self.lis_mons_league_tb_all_org
            
        if self.number_f1_pg.get() == 0:
            lis_mons_league_tb_pg = self.lis_mons_league_tb_org
        elif self.number_f1_pg.get() == 1:
            lis_mons_league_tb_pg = self.lis_mons_league_tb_all
        else:
            lis_mons_league_tb_pg = self.lis_mons_league_tb_all_org
        
        return lis_mons_league_tb_c, lis_mons_league_tb_pg


    # 相性基準のマークを返却。★ただし、相性閾値のこと全然知らないので、すべて仮値。
    def get_mark(self, affinity):
        
        mark = "×"
        
        if affinity > 610:
            mark = "☆"
        elif affinity > 490:
            mark = "◎"
        elif affinity > 374:
            mark = "〇"
        elif affinity > 257:
            mark = "△"
        else:
            mark = "×"
        
        return mark


    ## 子/親/祖父母間相性値の事前計算関数。min(m)用
    def precalc_affinity_cpg(self, lis_affinities_cp):

        # 子×親 + min(子×祖父, 親×祖父) + min(子×祖母, 親×祖母)の値を格納した4次元テーブル作成。
        # dim1：祖母、dim2：祖父、dim3：親、dim4:子
        
        # 3次元、4次元リスト作成
        length = len(lis_affinities_cp)
        work = [[[0 for i in range(length)] for j in range(length)] for k in range(length)]
        lis_affinities_cpg = [[[[0 for i in range(length)] for j in range(length)] for k in range(length)] for l in range(length)]
        
        # 計算…min(子×祖父, 親×祖父)参照用テーブル
        for child in range(length):
            for parent in range(length):
                for grand in range(length):
                    cg = lis_affinities_cp[child][grand]
                    pg = lis_affinities_cp[parent][grand]
                    work[child][parent][grand] = cg if cg < pg else pg
        
        # 実テーブル
        for child in range(length):
            for parent in range(length):
                cp = lis_affinities_cp[child][parent]
                for granpa in range(length):
                    for granma in range(length):
                        lis_affinities_cpg[child][parent][granpa][granma] = work[child][parent][granpa] + work[child][parent][granma] + cp
                        
        return lis_affinities_cpg
    

    ## 子→親系のメイン血統サブ血統合計値事前計算。min(m+s)用
    def precalc_affinity_m_s_cp(self, lis_affinities_m_cp, lis_affinities_s_cp):

        # 子→親へのメイン血統相性値+サブ血統相性値の合計値を格納した4次元テーブル作成。
        # dim1：親サブ、dim2:親メイン、dim3:子サブ、dim4:子メイン

        # 4次元作成
        length = len(lis_affinities_m_cp)
        lis_affinities_m_s_cp = [[[[0 for i in range(length)] for j in range(length)] for k in range(length)] for l in range(length)]
        
        # 計算…min(子×祖父, 親×祖父)参照用テーブル
        for child1 in range(length):
            for child2 in range(length):
                for parent1 in range(length):
                    for parent2 in range(length):
                        lis_affinities_m_s_cp[child1][child2][parent1][parent2]  = lis_affinities_m_cp[child1][parent1]  + lis_affinities_s_cp[child2][parent2]
                        
        return lis_affinities_m_s_cp


    # 相性値全通り計算関数(ひどいforループだ…もっと効率いい方法あるだろ！いい加減にしろ！)。min(m+s)用。
    def calc_affinity_m_s(self, Monster_info, thresh_aff, lis_mons_league_tb_c, lis_mons_league_tb_pg):

        # 愚直に計算。
        # min(m)とやり方は近く、事前計算できなくなった分、本関数で追加で実施している箇所あり。
        
        # 返却値
        ret = False
        N = 80000
        # 保管用リストの作成
        ped1_num = len(lis_mons_league_tb_c)
        ped2_num = len(lis_mons_league_tb_c)
        # lis_affinities_cpg1[child1][child2][parent1][parent2]
        lis_affinities_cpg1 = [[[[ [] for l in range(ped2_num)] for k in range(ped1_num)] for j in range(ped2_num)] for i in range(ped1_num)]
        lis_affinities_cpg2 = [[[[ [] for l in range(ped2_num)] for k in range(ped1_num)] for j in range(ped2_num)] for i in range(ped1_num)]
        lis_affinities      = []
        lis_child1          = []
        lis_child2          = [ [] for j in range(ped1_num) ]
        lis_parent1_1       = []
        lis_parent1_2       = [ [] for j in range(ped1_num) ]
        lis_parent2_1       = []
        lis_parent2_2       = [ [] for j in range(ped1_num) ]
        df_affinities       = pd.DataFrame( [] )
        # 参照高速化のためにローカル設定
        lis_affinities_m_s_cp = self.lis_affinities_m_s_cp
        lis_affinities_m_cp = self.lis_affinities_m_cp
        lis_affinities_s_cp = self.lis_affinities_s_cp

        # 子-親①-祖父①-祖母①のメイン/サブ血統(あり得ない組み合わせ、基準値以下はスキップ)
        i = 0
        # 子
        for child1 in Monster_info[0].ped1_num:
            for child2 in Monster_info[0].ped2_num:
                name_c = lis_mons_league_tb_c[child1][child2]
                if name_c == "-":
                    continue
                
                # 親
                for parent1 in Monster_info[1].ped1_num:
                    for parent2 in Monster_info[1].ped2_num:
                        name_p = lis_mons_league_tb_pg[parent1][parent2]
                        if name_p == "-":
                            continue
                        cp = lis_affinities_m_s_cp[child1][child2][parent1][parent2]
                        if cp < thresh_aff.th_p1:
                            continue
                        
                        # 祖父
                        for granpa1 in Monster_info[2].ped1_num:
                            for granpa2 in Monster_info[2].ped2_num:
                                name_g1 = lis_mons_league_tb_pg[granpa1][granpa2]
                                if name_g1 == "-":
                                    continue
                                cg1 = lis_affinities_m_s_cp[child1][child2][granpa1][granpa2]
                                pg1 = lis_affinities_m_s_cp[parent1][parent2][granpa1][granpa2]
                                cpg1 = cg1 if cg1 < pg1 else pg1
                                if cpg1 < thresh_aff.th_cpg1:
                                    continue

                                # 祖母
                                for granma1 in Monster_info[3].ped1_num:
                                    for granma2 in Monster_info[3].ped2_num:
                                        name_g2 = lis_mons_league_tb_pg[granma1][granma2]
                                        if name_g2 == "-":
                                            continue
                                        cg2 = lis_affinities_m_s_cp[child1][child2][granma1][granma2]
                                        pg2 = lis_affinities_m_s_cp[parent1][parent2][granma1][granma2]
                                        cpg2 = cg2 if cg2 < pg2 else pg2
                                        if cpg2 < thresh_aff.th_cpg1:
                                            continue

                                        # 格納
                                        lis_affinities_cpg1[child1][child2][parent1][parent2].append([cp + cpg1 + cpg2, name_c, name_p, name_g1, name_g2])
                                        if child1 not in lis_child1:
                                            lis_child1.append(child1)
                                        if child2 not in lis_child2[child1]:
                                            lis_child2[child1].append(child2)
                                        if parent1 not in lis_parent1_1:
                                            lis_parent1_1.append(parent1)
                                        if parent2 not in lis_parent1_2[parent1]:
                                            lis_parent1_2[parent1].append(parent2)
                                        i += 1
        self.print_Log(f"◎子-親①-祖父①-祖母②の組み合わせ：{i:,}件")
        if i >= N:
            self.show_error(f"候補が{N}件を超えたため停止します。\n閾値やリーグ表の見直しを実施してください。")
            return ret, df_affinities
        
        # 子-親②-祖父②-祖母②のメイン/サブ血統(あり得ない組み合わせ、基準値以下はスキップ)
        j = 0
        # 子
        for child1 in lis_child1:
            for child2 in lis_child2[child1]:
                name_c = lis_mons_league_tb_c[child1][child2]
                if name_c == "-":
                    continue
                
                # 親
                for parent1 in Monster_info[4].ped1_num:
                    for parent2 in Monster_info[4].ped2_num:
                        name_p = lis_mons_league_tb_pg[parent1][parent2]
                        if name_p == "-":
                            continue
                        cp = lis_affinities_m_s_cp[child1][child2][parent1][parent2]
                        if cp < thresh_aff.th_p2:
                            continue

                        # 祖父
                        for granpa1 in Monster_info[5].ped1_num:
                            for granpa2 in Monster_info[5].ped2_num:
                                name_g1 = lis_mons_league_tb_pg[granpa1][granpa2]
                                if name_g1 == "-":
                                    continue
                                cg1 = lis_affinities_m_s_cp[child1][child2][granpa1][granpa2]
                                pg1 = lis_affinities_m_s_cp[parent1][parent2][granpa1][granpa2]
                                cpg1 = cg1 if cg1 < pg1 else pg1
                                if cpg1 < thresh_aff.th_cpg2:
                                    continue

                                # 祖母
                                for granma1 in Monster_info[6].ped1_num:
                                    for granma2 in Monster_info[6].ped2_num:
                                        name_g2 = lis_mons_league_tb_pg[granma1][granma2]
                                        if name_g2 == "-":
                                            continue
                                        cg2 = lis_affinities_m_s_cp[child1][child2][granma1][granma2]
                                        pg2 = lis_affinities_m_s_cp[parent1][parent2][granma1][granma2]
                                        cpg2 = cg2 if cg2 < pg2 else pg2
                                        if cpg2 < thresh_aff.th_cpg2:
                                            continue

                                        # 格納
                                        # name_cの格納は不要だが、同形状のリストの方がバグを回避できそうなためそのままとする。
                                        lis_affinities_cpg2[child1][child2][parent1][parent2].append([cp + cpg1 + cpg2, name_c, name_p, name_g1, name_g2])
                                        if parent1 not in lis_parent2_1:
                                            lis_parent2_1.append(parent1)
                                        if parent2 not in lis_parent2_2[parent1]:
                                            lis_parent2_2[parent1].append(parent2)
                                        j += 1
        self.print_Log(f"◎子-親②-祖父②-祖母②の組み合わせ：{j:,}件")
        if j >= N:
            self.show_error(f"候補が{N}件を超えたため停止します。\n閾値やリーグ表の見直しを実施してください。")
            return ret, df_affinities
        
        # 親①-親②のメイン/サブ血統(基準値以下はスキップ)
        for child1 in lis_child1:
            for child2 in lis_child2[child1]:
                for parent1_1 in lis_parent1_1:
                    for parent2_1 in lis_parent2_1:
                        pp1 = lis_affinities_m_cp[ parent1_1 ][ parent2_1 ]
                        if pp1 < thresh_aff.th_ped1_pp:
                            continue
                        for parent1_2 in lis_parent1_2[parent1_1]:
                            for parent2_2 in lis_parent2_2[parent2_1]:
                                pp2 = lis_affinities_s_cp[ parent1_2 ][ parent2_2 ]
                                if pp2 < thresh_aff.th_ped2_pp:
                                    continue
                                for cpg1_record in lis_affinities_cpg1[child1][child2][parent1_1][parent1_2]:
                                    for cpg2_record in lis_affinities_cpg2[child1][child2][parent2_1][parent2_2]:
                                        affinity = pp1 + pp2 + cpg1_record[0] + cpg2_record[0]
                                        mark = self.get_mark(affinity)
                                        # 判定、相性値、各名前（子、親①、祖父①、祖母①、親②、祖父②、祖母②の順）
                                        lis_affinities.append([mark, affinity, 
                                                            cpg1_record[1], cpg1_record[2], 
                                                            cpg1_record[3], cpg1_record[4], 
                                                                            cpg2_record[2], 
                                                            cpg2_record[3], cpg2_record[4]] )

        # データフレーム型に変換してソート。
        self.print_Log(f"◎子-両親-祖父母①-祖父母②の組み合わせ：{len(lis_affinities):,}件")
        if len(lis_affinities) == 0:
            self.print_Log("候補0件。（他のログは出力しません。）")
            return ret, df_affinities

        df_affinities = pd.DataFrame( lis_affinities )
        df_affinities = df_affinities.sort_values([1, 2], ascending=[False, True])
        df_affinities.columns=['評価', '素相性値', '子', '親①', '祖父①', '祖母①', '親②', '祖父②', '祖母②']
        
        ret = True

        return ret, df_affinities.reset_index()




#### メインウィンドウ
if __name__ == "__main__":

    root = tk.Tk()
    app = Application(master = root)
    app.mainloop()

    